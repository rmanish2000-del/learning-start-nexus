# EduOS Remediation Package V1_CORRECTED

Generated from `EDUOS_GEMINI_INPUT_PACKAGE.zip` (SHA-256 `4029077de1acbdd59dc07f04a8d4d71b72b7881cb3a9d9e76e0a669a20636fe5`), export
timestamp 2026-09-09T16:29:07.059196+00:00, engine run `0ae8b0d0-4674-4f9e-8823-1d5aa2f2387f`, plus one frozen repository
evidence file (`EDUOS_CLASS_10_FINAL_QUESTION_REGISTER.json`, SHA-256 `23da8350ea6052e8fc98038747c111348397ab6752cd43f96126e3e7aaa25078`) used only for its
`numericCheck` recomputation specs and originality attestations.

**Status: proposals only.** Nothing was imported, applied, approved, certified, committed or deployed.
No database was read or written by this generator; it consumes the read-only export.

## What was actually executed
- Engine v1.0.0 re-implemented rule-for-rule from `src/lib/auto-verification-shared.ts` and re-run on all
  329 items (all nine checks, corpus-level duplicate detection, decision logic). Every recomputed check is
  compared with the stored evidence; disagreements are listed per item.
- Independent numeric recomputation of the register's `numericCheck` specs for the functions whose
  semantics are unambiguous (94 functions implemented); the result is compared with both the
  register's expected value and the recorded answer.
- Curriculum alignment against the crosswalk (outcome, unit, requirement token consistency).
- Exact duplication, engine near-duplication (Jaccard ≥ 0.85), and a lexical semantic-duplicate proxy.
- Copyright contamination against the engine's frozen NCERT overlap-candidate list.
- Pool separation from `external_ref` tokens, cross-pool near-duplicates, and live assessment usage
  versus pool intent.

## What could NOT be executed (never marked PASS)
- Open-response answer correctness (203 items): `SME_REVIEW_REQUIRED`.
- Verbatim NCERT/CBSE text comparison and PYQ comparison: `NOT_EVALUATED` (no source text in the package).
- Numeric recomputation for register functions with non-derivable semantics: `NOT_EVALUATED`.
- All content checks on the 210 legacy items: `NOT_EVALUATED` (content not exported).
- Official source confirmation beyond the two checksummed syllabus PDFs: `NOT_EVALUATED`.

## Counts (recomputed, not forced)
- Cohort 329 · automated approvals 123 · held 206 ·
  held with status=approved 150 · missing external_ref 3 · legacy Class 10 210 (3 General Knowledge rows excluded).
- Primary dispositions: {"CONFIRMED_AUTO_APPROVED": 123, "CONTENT_FIX_REQUIRED": 4, "METADATA_CORRECTION": 3, "REPLACEMENT_CANDIDATE": 5, "SME_REVIEW_REQUIRED": 194}
- Engine rerun candidates: 1. Gemini's prior 83/210/29/7 split was not adopted.

## Files
- `EDUOS_ALL_329_ITEM_EXPORT_VALIDATED.json` — master: all 329 items, content preserved, stored + recomputed evidence, independent checks, disposition
- `EDUOS_206_HELD_ITEMS_REMEDIATED.json` — the 206 held items with disposition and actions
- `EDUOS_210_LEGACY_VERIFICATION_REVIEW.json` — 210 legacy structurally-verified rows (Class 10 Maths/Science only)
- `EDUOS_MATHS_SME_REVIEW_QUEUE.csv`, `EDUOS_SCIENCE_SME_REVIEW_QUEUE.csv` — SME queues (all non-confirmed items plus confirmed items carrying a spot-check action)
- `EDUOS_REPLACEMENT_ITEMS.json` — replacement/rejection candidates with evidence
- `EDUOS_EXTERNAL_REF_CORRECTIONS.json` — 3 collision-free external_ref proposals (not applied)
- `EDUOS_APPROVED_FLAG_CORRECTIONS.json` — 150 approved-flag proposals (not applied)
- `EDUOS_DUPLICATE_REPORT.json`, `EDUOS_CONTAMINATION_REPORT.json`, `EDUOS_POOL_SEPARATION_REPORT.json` — quality reports from executed checks
- `EDUOS_COUNT_RECONCILIATION.json` — recomputed counts versus the assignment's authoritative counts
- `EDUOS_IMPORT_MANIFEST.json` — change sets, file list with SHA-256; `SHA256SUMS.txt` — checksums of every file
Rebuild: `python3 generate_remediation.py` (deterministic for identical inputs). Verify:
`python3 verify_remediation.py` (independent; shares no classification logic).
