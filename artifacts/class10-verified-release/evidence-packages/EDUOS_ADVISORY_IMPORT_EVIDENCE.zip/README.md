# EduOS staging automated provisional advisory import

These are automated provisional decisions created under founder authorization. They are not named-human SME decisions, copyright clearance, official CBSE/NCERT certification, or production approval.

- Source package: EDUOS_196_ENHANCED_AUTOMATED_REVIEW_PACKAGE.zip, 70019 bytes, SHA-256 6b01f2b202647a5ab415a02353c8bb44c9de5c538ee9e032c80752d03dda7f16
- Queue rows imported: 196; distinct questions: 195
- Outcomes (queue rows): 148 AUTOMATED_PROVISIONAL_PASS, 1 AUTOMATED_PROVISIONAL_CONTENT_FIX, 47 AUTOMATED_UNRESOLVED
- Outcomes (distinct questions): 148 / 1 / 46 (REQ024-DIAG-004 has two routing rows, one question)
- Every record is labelled FOUNDER_AUTHORIZED_AUTOMATED_PROVISIONAL with no human identity, qualification or signature, and no approval, verification, certification, content, pool or Engine v1.0.0 field was changed.
- Provisional-pass items remain excluded from paid selection and production export.

## Rollback

Staging: mark the advisory rows superseded and the import rolled_back, then append a ROLLBACK event (`scripts/class10/advisory/validate.py` exercises this); re-running `scripts/class10/advisory/import.py` restores an identical state hash.
Repository: `git revert <commit>` — non-destructive, leaves the append-only evidence intact.
