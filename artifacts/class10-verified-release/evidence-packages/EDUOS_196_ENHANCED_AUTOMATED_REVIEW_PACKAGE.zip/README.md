# EduOS Class 10 — Enhanced Automated Adjudication of the 196-item Remainder

These are automated provisional decisions created under founder authorization. They are not named-human SME decisions, copyright clearance, official CBSE/NCERT certification, or production approval.

- Environment: EduOS-staging only (`APP_ENV=staging`, database `qpinlkiwktedvnqrkfoq`).
- Staging commit at run time: `943f953fa13c9d88981016f3f01bc5bf4c241a9e`, clean worktree, no pending migrations.
- Input package: `EDUOS_AUTOMATED_REVIEW_PACKAGE.zip`, 49,574 bytes,
  SHA-256 `290af591b5080bc45b96c862d41c8b0cb2e0e3385f965f2b70dc0319274008c0` (verified before the run).
- Database mutations: 0. Commits: 0. Publications: 0. Deployments: 0. The run is read-only throughout.

## Scope

196 queue rows covering 195 distinct questions — `C10-2627-MATH-REQ024-DIAG-004` holds two rows
(`ENGINE_QUARANTINED` and `CONTAMINATION_HIT`) and is adjudicated once per row.

| Subject | Rows |
|---|---|
| Mathematics | 143 |
| Science | 53 |
| Total | 196 |

Mathematics and Science are adjudicated in separate files and were checked for isolation.

## Review method

Each item passes through three independent stages.

**PASS A — independent solution.** A deterministic solver reads the quantities out of the question text
and computes the answer from first principles (exact rational and symbolic arithmetic via sympy). It does
not read the stored answer, the stored explanation, or the authoring register. Where no solver can read the
wording — qualitative Science explanation items, proofs, and definition questions — PASS A records
`NOT_EXECUTED` rather than guessing.

**PASS B — adversarial verification.** Eight tests attack PASS A: a structurally different second
computation, a cross-check against the authoring register treated as a rival claim, rounding and
presentation variants, units and terminology, ambiguity and authoring artefacts, whether the explanation
establishes the final answer rather than an intermediate quantity, internal contradiction between answer
and explanation, and completeness against the demands in the prompt.

**PASS C — adjudication.** PASS A, PASS B, the stored answer, the explanation, curriculum and requirement
metadata, exact and semantic duplication evidence, contamination evidence, Engine v1.0.0 and the canonical
package are compared, and agreement or disagreement is recorded per item.

## Outcomes

| Subject | PROVISIONAL_PASS | CONTENT_FIX | UNRESOLVED |
|---|---|---|---|
| Mathematics | 128 | 0 | 15 |
| Science | 20 | 1 | 32 |
| Total | 148 | 1 | 47 |

No `AUTOMATED_PROVISIONAL_PASS_WITH_METADATA_FIX`, `AUTOMATED_PROVISIONAL_REPLACEMENT` or
`AUTOMATED_PROVISIONAL_REJECT` outcome was reached: no remaining item carried a metadata failure, an exact
duplicate, or an invalid premise.

Independent derivation succeeded for 154 of the 196 rows. In all 154 the stored answer agreed with the
independently derived result; there were zero stored-answer disagreements.

## Evidence rules enforced

1. A provisional pass requires an executed independent derivation, agreement with the stored answer, no
   PASS B contradiction, and an explanation that establishes the answer.
2. Unavailable checks are recorded as `NOT_EXECUTED` and can never carry `PASS`.
3. Official-source confirmation, copyright clearance and verbatim source-text comparison are declared
   `NOT_EXECUTED` on every item — no corpus of official text exists in the evidence set.
4. Semantic similarity alone never rejects or replaces an item.
5. No reviewer identity, qualification or signature appears anywhere; those fields are explicitly `null`.
6. Nothing was written back: content, answers, explanations, metadata, status, verification flags and pool
   membership are unchanged in the database.

## Unresolved (47)

- 42 rows have no machine-readable solution path: qualitative Science explanation items, proofs
  ("show that root 3 is irrational"), definitions and reasoning questions. Correctness here is a judgement
  a deterministic solver cannot make, and the run does not pretend otherwise.
- 5 rows are flagged against the frozen NCERT overlap list. Overlap is a copyright question; no check in
  this evidence set can clear it, so no provisional pass is possible regardless of mathematical
  correctness. This includes both rows of `C10-2627-MATH-REQ024-DIAG-004` (C2).

## Special conditions

- **C1** — `REQ001-DIAG-001`, `REQ001-DIAG-005`, `REQ001-DIAG-009` keep their active paid-diagnostic
  exclusions and work item `REASSESSMENT-146ec7c8-POOL-BREACH` remains open. The pool conflict is not
  resolved or reclassified. These three items are Engine-auto-approved, so they are not part of the
  196-row remainder.
- **C2** — `C10-2627-MATH-REQ024-DIAG-004` is adjudicated as a contamination hit in the Mathematics file,
  outcome `AUTOMATED_UNRESOLVED`, frozen overlap list unmodified, no copyright clearance claimed.

## Determinism

Two complete runs of the generator and validator produced byte-identical output trees.

## Files

| File | Contents |
|---|---|
| `EDUOS_MATHS_143_ENHANCED_AUTOMATED_REVIEW.json` | 143 Mathematics rows with full three-pass evidence |
| `EDUOS_SCIENCE_53_ENHANCED_AUTOMATED_REVIEW.json` | 53 Science rows with full three-pass evidence |
| `EDUOS_196_AUTOMATED_ADJUDICATION_SUMMARY.json` | Counts, check statistics, C1/C2, engine consistency |
| `EDUOS_AUTOMATED_PROVISIONAL_PASS_ITEMS.csv` | The 148 provisional passes |
| `EDUOS_AUTOMATED_FIX_ITEMS.csv` | The 1 content-fix recommendation |
| `EDUOS_AUTOMATED_REPLACEMENT_REJECT_ITEMS.csv` | Replacement and reject recommendations (empty) |
| `EDUOS_AUTOMATED_UNRESOLVED_ITEMS.csv` | The 47 unresolved rows with reasons |
| `EDUOS_ENHANCED_REVIEW_VALIDATION.json` | 27 independent validations, no shared classification logic |
| `SHA256SUMS.txt` | Checksums for every file above |

## Limitations

No official CBSE/NCERT text corpus is available, so source alignment, verbatim overlap and copyright
status remain unestablished for the whole corpus. Qualitative correctness, pedagogical quality and
grade-appropriateness are not machine-decidable and were not decided. A provisional pass means the answer
is mathematically or numerically reproducible from the question — it is not a substitute for named subject
expert review before production release.
