# EduOS Class 10 — Automated Mathematics and Science Content Review

This package contains automated recommendations, not named-SME decisions, human certification, copyright clearance, or production approval.

- Environment: EduOS-staging only (`APP_ENV=staging`, database `qpinlkiwktedvnqrkfoq`).
- Staging commit at run time: `943f953fa13c9d88981016f3f01bc5bf4c241a9e` (clean, no pending migrations).
- Database mutations: 0. Commits: 0. Publications: 0. Deployments: 0. The entire run is read-only.
- Engine: EduOS deterministic verification engine v1.0.0 (`src/lib/auto-verification-shared.ts`), rerun over the
  full 329-item corpus so that corpus-level duplicate detection is correct; results reported for the 207 queued items.

## Scope

| Subject | Queued items | Reviewed |
|---|---|---|
| Mathematics | 148 | 148 |
| Science | 59 | 59 |
| Total | 207 | 207 |

Mathematics and Science results are kept in separate files and were validated for subject isolation.

## Outcome vocabulary

Only these values are used: `AUTOMATED_APPROVE_RECOMMENDATION`, `AUTOMATED_METADATA_CORRECTION_RECOMMENDATION`,
`AUTOMATED_CONTENT_FIX_RECOMMENDATION`, `AUTOMATED_REPLACEMENT_RECOMMENDATION`, `AUTOMATED_REJECT_RECOMMENDATION`,
`HUMAN_REVIEW_REQUIRED`, `NOT_EVALUATED`. A bare "APPROVE" is never used.

## Evidence rules applied

1. Every item carries check-level evidence with an explicit `executed` flag.
2. A check that was not executed is always recorded as `NOT_EVALUATED` and can never carry `PASS`.
3. Open-response correctness is never machine-recommended; it is `HUMAN_REVIEW_REQUIRED`.
4. Semantic similarity alone never produces a duplicate rejection.
5. Existing overlap evidence never establishes copyright clearance or originality.
6. No reviewer identity, qualification, or signature is present in any output; the fields are explicitly `null`.
7. No question content, answer, explanation, metadata, status, verification flag, or pool membership was changed.

## Special conditions

- **C1** — `REQ001-DIAG-001`, `REQ001-DIAG-005`, `REQ001-DIAG-009`: active paid-diagnostic exclusions and the open
  work item `REASSESSMENT-146ec7c8-POOL-BREACH` are preserved unchanged. The pool conflict is not resolved or
  reclassified. These three items are Engine-auto-approved and therefore sit outside the 207-item review queue.
- **C2** — `C10-2627-MATH-REQ024-DIAG-004`: treated as a contamination hit, routed to the Mathematics queue,
  normalized-whitespace evidence preserved, frozen overlap list unmodified, no copyright clearance claimed.

## Files

| File | Contents |
|---|---|
| `EDUOS_MATHEMATICS_AUTOMATED_REVIEW.json` | Item-level evidence and recommendations for 148 Mathematics items |
| `EDUOS_SCIENCE_AUTOMATED_REVIEW.json` | Item-level evidence and recommendations for 59 Science items |
| `EDUOS_AUTOMATED_REVIEW_SUMMARY.json` | Counts by subject and outcome, per-check statistics, engine rerun, C1/C2 |
| `EDUOS_HUMAN_REVIEW_REMAINDER_MATHS.csv` | Mathematics items still needing a named human expert |
| `EDUOS_HUMAN_REVIEW_REMAINDER_SCIENCE.csv` | Science items still needing a named human expert |
| `EDUOS_AUTOMATED_REVIEW_VALIDATION.json` | Independent consistency validation over every generated result |
| `SHA256SUMS.txt` | Checksums for every file above |

## Determinism

The generator was executed twice with identical inputs; the two output trees are byte-identical, and the engine
rerun output hashes to the same SHA-256 on both runs.
